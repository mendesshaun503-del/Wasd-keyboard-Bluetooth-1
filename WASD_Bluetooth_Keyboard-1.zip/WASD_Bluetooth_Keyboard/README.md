# WASD Bluetooth Keyboard

Android app that presents a full-screen landscape WASD + Space touch keyboard and exposes the phone as a Bluetooth HID keyboard.

## What it does
- Landscape/full-screen UI
- W, A, S, D and Space
- Multi-touch support so multiple keys can be held at once
- Bluetooth HID keyboard reports (standard 8-byte boot-style keyboard report)
- Pair/connect to a Bluetooth host device

## Important compatibility note
Android exposes Bluetooth HID Device through `BluetoothHidDevice` from API 28, but whether a particular phone/OEM exposes and permits the HID Device profile can vary. The app reports when HID is unavailable.

## Build
Open this folder in Android Studio and run the `app` configuration on an Android 9+ phone.
