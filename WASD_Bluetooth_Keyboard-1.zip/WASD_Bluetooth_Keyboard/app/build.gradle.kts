plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.wasdkeyboard"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.example.wasdkeyboard"
        minSdk = 28
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
