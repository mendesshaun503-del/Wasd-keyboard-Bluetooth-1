package com.example.wasdkeyboard

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var hid: HidKeyboard
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 20)
        }

        hid = HidKeyboard(this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 20)
            setBackgroundColor(Color.rgb(8,8,8))
        }

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        status = TextView(this).apply {
            text = "Bluetooth keyboard • starting…"
            textSize = 15f
            setTextColor(Color.LTGRAY)
        }
        top.addView(status, LinearLayout.LayoutParams(0, 50, 1f))

        val connect = Button(this).apply {
            text = "PAIR / CONNECT"
            setOnClickListener { hid.connectBestPairedHost() }
        }
        top.addView(connect, LinearLayout.LayoutParams(190, 50))
        root.addView(top)

        val keys = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val rowW = LinearLayout(this).apply { gravity = Gravity.CENTER }
        rowW.addView(key("W", 0x1A), LinearLayout.LayoutParams(0, 0, 1f).apply { setMargins(6,6,6,6) })
        keys.addView(rowW, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        for ((label, code) in listOf("A" to 0x04, "S" to 0x16, "D" to 0x07)) {
            row.addView(key(label, code), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(6,6,6,6) })
        }
        keys.addView(row, LinearLayout.LayoutParams(-1, 0, 1.25f))

        val space = key("SPACE", 0x2C)
        keys.addView(space, LinearLayout.LayoutParams(-1, 0, 0.8f).apply { setMargins(6,6,6,6) })
        root.addView(keys, LinearLayout.LayoutParams(-1, 0, 1f))

        hid.onStatus = { s -> runOnUiThread { status.text = s } }
        setContentView(root)
    }

    private fun key(label: String, code: Int): TextView {
        return TextView(this).apply {
            text = label
            textSize = if (label == "SPACE") 22f else 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = getDrawable(com.example.wasdkeyboard.R.drawable.key_background)
            isClickable = true
            isFocusable = true
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                        hid.keyDown(code); true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                        hid.keyUp(code); true
                    }
                    else -> true
                }
            }
        }
    }

    override fun onDestroy() {
        hid.close()
        super.onDestroy()
    }
}

private class HidKeyboard(private val context: Context) {
    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var profile: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private val pressed = linkedSetOf<Int>()
    private val executor = Executors.newSingleThreadExecutor()
    var onStatus: ((String) -> Unit)? = null

    private val descriptor = byteArrayOf(
        0x05,0x01,0x09,0x06,0xA1.toByte(),0x01,
        0x05,0x07,0x19.toByte(),0xE0.toByte(),0x29,0xE7.toByte(),0x15,0x00,0x25,0x01,
        0x75,0x01,0x95,0x08,0x81.toByte(),0x02,
        0x95,0x01,0x75,0x08,0x81.toByte(),0x01,
        0x95,0x05,0x75,0x01,0x05,0x08,0x19,0x01,0x29,0x05,0x91.toByte(),0x02,
        0x95,0x01,0x75,0x03,0x91.toByte(),0x01,
        0x95,0x06,0x75,0x08,0x15,0x00,0x25,0x65,0x05,0x07,0x19,0x00,0x29,0x65,0x81.toByte(),0x00,
        0xC0.toByte()
    )

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(device: BluetoothDevice?, registered: Boolean) {
            onStatus?.invoke(if (registered) "Bluetooth keyboard ready • pair the target device" else "Bluetooth HID stopped")
        }
        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                host = device
                onStatus?.invoke("Connected to ${device?.name ?: "device"}")
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                onStatus?.invoke("Disconnected")
            }
        }
        override fun onGetReport(device: BluetoothDevice, type: Byte, id: Byte, bufferSize: Int) {
            profile?.replyReport(device, BluetoothHidDevice.REPORT_TYPE_INPUT, id, ByteArray(8))
        }
        override fun onSetReport(device: BluetoothDevice, type: Byte, id: Byte, data: ByteArray) {
            profile?.reportError(device, BluetoothHidDevice.ERROR_RSP_SUCCESS)
        }
        override fun onSetProtocol(device: BluetoothDevice, protocol: Byte) {}
    }

    init {
        if (Build.VERSION.SDK_INT >= 28 && adapter != null) {
            adapter.getProfileProxy(context, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(profileId: Int, proxy: BluetoothProfile) {
                    if (profileId == BluetoothProfile.HID_DEVICE) {
                        profile = proxy as BluetoothHidDevice
                        val sdp = BluetoothHidDeviceAppSdpSettings(
                            "WASD Keyboard", "Touch WASD + Space keyboard", "WASD Keyboard",
                            BluetoothHidDevice.SUBCLASS1_KEYBOARD, descriptor
                        )
                        profile!!.registerApp(sdp, null, null, executor, callback)
                    }
                }
                override fun onServiceDisconnected(profileId: Int) {
                    if (profileId == BluetoothProfile.HID_DEVICE) profile = null
                }
            }, BluetoothProfile.HID_DEVICE)
        }
    }

    fun connectBestPairedHost() {
        val p = profile ?: run { onStatus?.invoke("Bluetooth HID is unavailable on this phone"); return }
        try {
            val bonded = adapter?.bondedDevices.orEmpty()
            val candidate = bonded.firstOrNull()
            if (candidate == null) {
                onStatus?.invoke("No paired device — pair this phone as a keyboard first")
                return
            }
            host = candidate
            p.connect(candidate)
            onStatus?.invoke("Connecting to ${candidate.name ?: "device"}…")
        } catch (e: SecurityException) {
            onStatus?.invoke("Bluetooth permission is required")
        }
    }

    fun keyDown(code: Int) {
        if (pressed.add(code)) send()
    }
    fun keyUp(code: Int) {
        if (pressed.remove(code)) send()
    }
    private fun send() {
        val device = host ?: return
        val p = profile ?: return
        val keys = pressed.take(6).map { it.toByte() }.toByteArray()
        val report = ByteArray(8)
        for (i in keys.indices) report[2 + i] = keys[i]
        try { p.sendReport(device, 0, report) } catch (_: SecurityException) {}
    }
    fun close() {
        try { profile?.unregisterApp() } catch (_: Exception) {}
        executor.shutdownNow()
    }
}
